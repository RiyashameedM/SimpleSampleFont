﻿namespace SimpleSampleFont
{
	public partial class MainPage : ContentPage
	{
		public MainPage()
		{
			InitializeComponent();
		}
		protected override void OnAppearing()
		{
			base.OnAppearing();
			Label label = new Label()
			{
				Text = "Text",
				TextColor = Colors.Red,
				FontSize = 16f,
				FontFamily = "OpenSansSemibold",
				VerticalTextAlignment = Microsoft.Maui.TextAlignment.Center,
				HorizontalTextAlignment = Microsoft.Maui.TextAlignment.Center,
			};
			stack.Children.Add(label);
		}
	}
}