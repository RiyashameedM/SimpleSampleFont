﻿using Microsoft.Maui.LifecycleEvents;

namespace MauiLib1
{
	// All the code in this file is included in all platforms.
	public static class AppHostBuilderExtensions
	{
		/// <summary>
		/// Configures the implemented handlers in Syncfusion.Maui.Core.
		/// </summary>
		/// <param name="builder"></param>
		/// <returns></returns>
		public static MauiAppBuilder ConfigureCore(this MauiAppBuilder builder)
		{


			builder.ConfigureFonts(fonts =>
			{
				fonts.AddEmbeddedResourceFont(typeof(AppHostBuilderExtensions).Assembly, "OpenSans-Semibold.ttf", "OpenSans-Semibold");
			});

			return builder;
		}
	}
}